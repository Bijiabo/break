define([], function(){
	var keys = {
        Color: 'Color',
        Weight: 'Weight',
        WorkTime: 'WorkTime',
    };
    return keys;
})