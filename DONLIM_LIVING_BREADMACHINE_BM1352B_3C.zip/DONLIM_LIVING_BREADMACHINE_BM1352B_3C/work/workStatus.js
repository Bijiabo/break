define([], function() {
	var statusList = {
		commonStatusList: [
			"预约中",
			"搅拌1",
			"发酵1",
			"搅拌2",
			"发酵2",
			"搅拌3",
			"发酵3",
			"烘烤",
			"保温",
			"出炉",
		]
	};
	return statusList
})