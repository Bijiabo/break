/**
 * Created by huchunbo on 2017/2/17.
 */
define(['./js/manager/recordManager'], function (record) {

    // record.add('start', '')
    record.addWithSubtype('start', 'run');
    record.addWithSubtype('stop', 'run');

});